package MyApp;

use Catalyst 'ServeFile';

MyApp->setup;
